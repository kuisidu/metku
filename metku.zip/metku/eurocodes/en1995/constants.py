# -*- coding: utf-8 -*-
"""
Created on Mon Jan  4 12:45:41 2021

Constants from EN 1995

@author: kmela
"""

