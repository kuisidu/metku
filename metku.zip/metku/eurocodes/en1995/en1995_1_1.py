# -*- coding: utf-8 -*-
"""
Created on Mon Jan  4 12:48:16 2021

Design rules of EN 1995-1-1, Design of Timber Structures

@author: kmela
"""

