# -*- coding: utf-8 -*-
"""
Created on Mon Jan  4 12:43:50 2021

Eurocodes package

Subpackage: en1995

Implementation of EN 1995 Design of timber structures

@author: kmela
"""
