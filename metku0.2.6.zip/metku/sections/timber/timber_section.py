"""
Timber section parameters, including timber fire design calculations (simple method)

@author: Viktor Haimi
"""

from abc import ABC
import numpy as np
from eurocodes.en1995 import en1995_1_1, en1995_1_2
from materials.timber_data import Timber, T
import matplotlib.pyplot as plt
from typing import Type, TypeVar

Num = TypeVar('Num', int, float)

class FireProtection():
    def __init__(self, t_ch: Num, b: Num, t_f: Num=None, t_a: Num=None):
        self.h_p = b
        self.t_ch = t_ch
        self.t_f = t_f
        self.t_a = t_a
        self.prot_mat = None
        self.prot_mat_beta_0 = None
        self.prot_mat_beta_n = None

    def protected_material(self, mat):
        beta_0, beta_n = en1995_1_2.charring_speed(mat.rhok, mat.type, mat.hardness, self.h_p)
        self.prot_mat = mat
        self.prot_mat_beta_0 = beta_0
        self.prot_mat_beta_n = beta_n


    def set_ta(self):
        t_a = min(2 * self.t_f, 25 / 2 * self.prot_mat_beta_n + self.t_f)
        self.t_a = t_a

    def set_tf_for_gypsumF(self):
        self.t_f = 12.5 / (0.73 * self.prot_mat_beta_n) + self.t_ch

class TimberSection():
    """Kommentti"""
    def __init__(self, material: Timber, B: Num, H: Num, Ned: Num=0.0, Med: Num=0.0, Ved: Num=0.0, design_code=en1995_1_1,
                 fire_protection_right=None, fire_protection_left=None,
                 fire_protection_top=None, fire_protection_bottom=None,
                 fire_protection_generic=None, fire_protection_sides=3, sides_on_fire=3):
        """

        @param material: materiaali
        @param B: leveys
        @param H: korkeus
        @param Ned: ?
        @param Med: ?
        @param Ved: ?
        @param design_code: kantsis olla 1995_1_1
        @param fire_protection_right: palosuoja joka laitetaan oikealle, yliajaa fire_protection_genericin
        @param fire_protection_left: palosuoja joka laitetaan vasemmalle, yliajaa fire_protection_genericin
        @param fire_protection_top: palosuoja joka laitetaan ylös, yliajaa fire_protection_genericin
        @param fire_protection_bottom: palosuoja joka laitetaan alas, yliajaa fire_protection_genericin
        @param fire_protection_generic: geneerinen palosuoja joka annetaan monelle sivulle samaan aikaan
        @param fire_protection_sides: jos antaa 3 niin fire_protection_top jää tyhjäksi.
                                      jos antaa jonkun muun kuin 3 niin suojaa kaikki neljä sivua fire_protection_genericillä
        @param sides_on_fire: jos antaa 4 niin poltetaan kaikilta neljältä sivulta,
                              jos antaa jonkun muun kuin 4 niin poltetaan kolmelta sivulta. (ylhäältä ei polteta)
        """
        self.material = material
        self.nu = 0.2
        self.__H = H
        self.__B = B

        self.Ned = Ned
        self.Med = Med
        self.Ved = Ved
        self.code = design_code

        self.beta_0, self.beta_n = en1995_1_2.charring_speed(self.material.rhok, self.material.type,
                                                             self.material.hardness, min(self.__B, self.__H))

        self.R = 0

        self.fire_protection_sides = fire_protection_sides
        self.sides_on_fire = sides_on_fire
        if fire_protection_sides == 3:
            self.fire_protection_right = fire_protection_right if fire_protection_right else fire_protection_generic
            self.fire_protection_left = fire_protection_left if fire_protection_left else fire_protection_generic
            self.fire_protection_bottom = fire_protection_bottom if fire_protection_bottom else fire_protection_generic
            self.fire_protection_top = fire_protection_top
        else:
            self.fire_protection_right = fire_protection_right if fire_protection_right else fire_protection_generic
            self.fire_protection_left = fire_protection_left if fire_protection_left else fire_protection_generic
            self.fire_protection_bottom = fire_protection_bottom if fire_protection_bottom else fire_protection_generic
            self.fire_protection_top = fire_protection_top if fire_protection_top else fire_protection_generic

        if self.fire_protection_right:
            self.fire_protection_right.protected_material(self.material)
            if isinstance(self.fire_protection_right, (GypsumPlasterboardF, GypsumPlasterboardFF, GypsumPlasterboardAF)):
                self.fire_protection_right.set_tf_for_gypsumF()
            self.fire_protection_right.set_ta()
        if self.fire_protection_left:
            self.fire_protection_left.protected_material(self.material)
            if isinstance(self.fire_protection_left, (GypsumPlasterboardF, GypsumPlasterboardFF, GypsumPlasterboardAF)):
                self.fire_protection_left.set_tf_for_gypsumF()
            self.fire_protection_left.set_ta()
        if self.fire_protection_bottom:
            self.fire_protection_bottom.protected_material(self.material)
            if isinstance(self.fire_protection_bottom, (GypsumPlasterboardF, GypsumPlasterboardFF, GypsumPlasterboardAF)):
                self.fire_protection_bottom.set_tf_for_gypsumF()
            self.fire_protection_bottom.set_ta()
        if self.fire_protection_top:
            self.fire_protection_top.protected_material(self.material)
            if isinstance(self.fire_protection_top, (GypsumPlasterboardF, GypsumPlasterboardFF, GypsumPlasterboardAF)):
                self.fire_protection_top.set_tf_for_gypsumF()
            self.fire_protection_top.set_ta()

    @property
    def H(self):
        h = self.__H
        h -= self.d_char_n(self.fire_protection_bottom, self.R, self.beta_n)
        if self.sides_on_fire == 4:
            h -= self.d_char_n(self.fire_protection_top, self.R, self.beta_n)
        return h

    @H.setter
    def H(self, val):
        self.__H = val

    @property
    def B(self):
        b = self.__B
        b -= self.d_char_n(self.fire_protection_right, self.R, self.beta_n)
        # TODO nurkkapilarit tarkistettava
        b -= self.d_char_n(self.fire_protection_left, self.R, self.beta_n)
        return b

    @B.setter
    def B(self, val):
        self.__B = val

    @property
    def I(self):
        return np.asarray([(self.B * self.H ** 3) / 12, (self.H * self.B ** 3) / 12])

    @property
    def Wel(self):
        return np.asarray([(self.B * self.H ** 2) / 6, (self.H * self.B ** 2) / 6])

    @property
    def k_h(self):
        # TODO pitää kysyä samilta
        if self.material.rhok <= 700 and self.material.type == 'solid_timber':
            if self.Ned > 0 and self.B < 150 and self.Med != 0 and self.H < 150:
                return min(min(1.3, (150 / self.B) ** 0.2), min(1.3, (150 / self.H) ** 0.2))
            elif self.Ned > 0 and self.B < 150:
                return min(1.3, (150 / self.B) ** 0.2)
            elif self.Med != 0 and self.H < 150:
                return min(1.3, (150 / self.H) ** 0.2)
            else:
                return 1.0
        elif self.material.type == 'glt':
            if self.Ned > 0 and self.B < 600 and self.Med != 0 and self.H < 600:
                return min(min(1.1, (600 / self.B) ** 0.1), min(1.1, (600 / self.H) ** 0.1))
            elif self.Ned > 0 and self.B < 600:
                return min(1.1, (600 / self.B) ** 0.1)
            elif self.Med != 0 and self.H < 600:
                return min(1.1, (600 / self.H) ** 0.1)
            else:
                return 1.0
        elif self.material.type == 'lvl':
            if self.Med != 0 and self.H != 300:
                return min(1.2, (300 / self.H) ** self.material.s)
            else:
                return 1.0
        else:
            return 1.0

    def __repr__(self):
        return f"{self.material.timber_type} {self.H:.0f}X{self.B:.0f}"


    #########################  SFS-EN 1995-1-2 FIRE DESIGN ##########################

    @property
    def A(self):
        '''
        Laskee palolle altistuneen rakenteen poikkileikkauksen tehollisen pinta-alan palonkestoajan funktiona
        @return: tehollinen pinta-ala A_ef [mm^2]
        '''

        b = self.B
        h = self.H

        if b <= 0 or h <= 0:
            return 0
        return b*h

    def d_char_n(self, fp: Type[FireProtection], t: Num, beta_n: float) -> float:
        """
        Returns the burned depth of single side
        @param fp: fire protection on the side
        @param t: how long the fire has burned
        @param beta_n: charring speed
        @return: depth of charring
        """

        k0 = 1.0
        d0 = 7
        if fp:
            if fp.t_ch <= 20:
                if t < 20:
                    k0 = t / 20
            else:
                if t <= fp.t_ch:
                    k0 = t/fp.t_ch
        else:
            if t < 20:
                k0 = t / 20

        if not fp:
            return t * beta_n + k0 * d0
        if t < fp.t_ch:
            return 0
        if fp.t_ch < fp.t_f:
            if t < fp.t_f:
                return (t - fp.t_ch) * 0.73 * beta_n + k0 * d0
            elif fp.t_f < t < fp.t_a:
                return (fp.t_f - fp.t_ch) * 0.73 * beta_n + (t - fp.t_f) * 2 * beta_n + k0 * d0
            else:
                return (fp.t_f - fp.t_ch) * 0.73 * beta_n + (fp.t_a - fp.t_f) * 2 * beta_n + (t - fp.t_a) * beta_n + k0 * d0
        if t < fp.t_a:
            dt = t - fp.t_f
            return 2 * beta_n * dt + k0 * d0
        else:
            t_fa = fp.t_a - fp.t_f
            dt = t - fp.t_a
            return 2 * beta_n * t_fa + beta_n * dt + k0 * d0

    def get_R(self):
        return self.R

class GypsumPlasterboardA(FireProtection):
    """
    Parameter
    """
    def __init__(self, sauma):
        if sauma < 2:
            super().__init__(22, 13, 22)
        else:
            super().__init__(13, 13, 13)

class GypsumPlasterboardF(FireProtection):
    def __init__(self, sauma):
        if sauma < 2:
            super().__init__(28, 15)
        else:
            super().__init__(19, 15)

class GypsumPlasterboardH(FireProtection):
    def __init__(self, sauma):
        if sauma < 2:
            super().__init__(11, 9, 11)
        else:
            super().__init__(2, 9, 2)

class GypsumPlasterboardAA(FireProtection):
    def __init__(self, sauma):
        if sauma < 2:
            super().__init__(40, 26, 40)
        else:
            super().__init__(31, 26, 31)

class GypsumPlasterboardFF(FireProtection):
    def __init__(self, sauma):
        if sauma < 2:
            super().__init__(61, 30)
        else:
            super().__init__(52, 30)

class GypsumPlasterboardHH(FireProtection):
    def __init__(self, sauma):
        if sauma < 2:
            super().__init__(23, 18, 23)
        else:
            super().__init__(14, 18, 14)

class GypsumPlasterboardAF(FireProtection):
    def __init__(self, sauma):
        if sauma < 2:
            super().__init__(46, 28)
        else:
            super().__init__(37, 28)

class WoodenFireProtection(FireProtection):
    def __init__(self, material, h_p):
        beta_0, beta_n = en1995_1_2.charring_speed(material.rhok, material.type, material.hardness, h_p)
        t_ch = h_p / beta_0
        super().__init__(t_ch, h_p, t_ch)

if __name__ == '__main__':
    '''
    TODO tehollinen pinta-ala pienenee millä tahansa palonketoajalla 
    Katso RIL 205-2-2009 lauseke 4.1.1 s. 32
    
    
    '''
    #sec = TimberSection(Timber(T.C30), 400, 200, sides_on_fire=4, fire_protection_sides=4, fire_protection_generic=WoodenFireProtection(Timber(), 20))
    #sec = TimberSection(Timber(), 400, 200, sides_on_fire=4, fire_protection_sides=4, fire_protection_generic=GypsumPlasterboardFF(1))
    sec = TimberSection(Timber(T.C30), 400, 200, sides_on_fire=4)
    sec2 = TimberSection(Timber(T.GL24h), 400, 200, sides_on_fire=4)

    x = []
    y = []
    x2 = []
    y2 = []

    for i in range(90):
        sec.R = i
        sec2.R = i
        x.append(i)
        y.append(sec.A)
        x2.append(i)
        y2.append(sec2.A)

    # for i in range(90):
    #     x.append(i)
    #     y.append(sec.d_char_n(sec.fire_protection_right, i, sec.beta_n))
    #     x2.append(i)
    #     y2.append(sec2.d_char_n(sec2.fire_protection_right, i, sec2.beta_n))

    plt.plot(x, y, 'r', x2, y2, 'g')
    plt.show()