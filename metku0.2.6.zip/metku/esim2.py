from structures.timber.timber_member import TimberMember
from structures.timber.timber_frame2d import TimberFrame2D
from materials.timber_data import T
from sections.timber.timber_section import TimberSection, GypsumPlasterboardF, WoodenFireProtection, GypsumPlasterboardA
import frame2d.frame2d as f2d
import numpy as np

fr = TimberFrame2D()

coord1 = [[0, 0], [0, 5000]]
coord3 = [[0, 5000], [20000, 5000]]
coord2 = [[20000, 5000], [20000, 0]]
fr.add(TimberMember(T.GL32c, 200, 200, coord1, 'instantaneous', 1))
fr.add(TimberMember(T.GL32c, 400, 200, coord3, 'instantaneous', 1, num_elements=8, Sj1=np.inf, Sj2=np.inf))
fr.add(TimberMember(T.GL32c, 200, 200, coord2, 'instantaneous', 1))

fr.members[0].section = TimberSection(fr.members[0].material, fr.members[0].B, fr.members[0].H,
                                      fire_protection_generic=GypsumPlasterboardF(1),
                                      fire_protection_right=GypsumPlasterboardA(1))

R = 46
fr.members[0].R = R
fr.members[1].R = R
fr.members[2].R = R

fr.add(f2d.LineLoad(fr.members[1], [-15, -15], 'y'))
fr.add(f2d.LineLoad(fr.members[0], [3, 3], 'x'))
fr.add(f2d.XYHingedSupport([0, 0]))
fr.add(f2d.XYHingedSupport([20000, 0]))
fr.generate()
fr.calculate()
fr.bmd(1)
