"""
Timber member

@author Viktor Haimi
"""
from math import log, tan, pi, sqrt, isclose
import numpy as np
import matplotlib.pyplot as plt
from materials.timber_data import Timber, T
from eurocodes.en1995.en1995_1_1 import kmod, kdef, k_to_d, get_gammaM, k_m
from sections.timber.timber_section import TimberSection
from framefem.elements import EBBeam, EBSemiRigidBeam, Rod
from sections.steel.ISection import HEA

PREC = 5

class TimberMember:
    def __init__(self, material, H, B, coordinates, ldc, sc, num_elements=5, mem_id=1, lcr=(0.9, 0.9), varnished=False,
                 Sj1=np.inf, Sj2=np.inf, reverse=False):
        """
        Initialization method for timber member
        @param material:    sauvan materiaali muodossa: C14..D70 / GL24c..GL32h
        @param H:           sauvan poikkileikkauksen korkeus
        @param B:           sauvan poikkileikkauksen leveys
        @param length:      sauvan pituus
        @param ldc:         kuorman aikaluokka
        @param sc:          rakenneosan käyttöluokka
        @param lcr:         nurjahduskerroin
        """
        self.material = Timber(timber_type=material)
        self.H = H
        self.B = B
        self.lcr = lcr
        self.ldc = ldc
        self.sc = sc
        self.varnished = varnished

        self.mem_id = mem_id

        self.num_elements = num_elements
        self.added_coordinates = []
        self.nodal_coordinates = []
        self.node_locs = []
        self.nodes = {}
        self.nodal_forces = {}
        self.elements = {}
        self.nodal_displacements = {}
        self.r = np.ones(9)
        self.is_strong_enough = False
        self.ecc_elements = {}
        self.ecc_coordinates = []
        self.ecc_element_nodes = {}
        self.is_generated = False
        self.element_ids = []
        self.__Sj1 = None
        self.__Sj2 = None
        self.Sj1 = Sj1
        self.Sj2 = Sj2
        self.n1 = None
        self.n2 = None
        self.coordinates = [[round(c, PREC) for c in coords] for coords in coordinates]
        self.reverse = reverse
        self.loads = []

        if pi/2 - 0.05 < self.angle < pi/2 + 0.05:
            self.mtype = "column"
        else:
            self.mtype = "beam"

        self.ned = []
        self.myed = []
        self.mzed = []
        self.vyed = []
        self.vzed = []
        self.ted = []
        self.loc = []

        self.Ned = 0
        self.Ved = 0
        self.Med = 0

        self.kmod = kmod(self.material.type, self.sc, self.ldc)

        self.section = TimberSection(self.material, B, H)
        self.R = 0

        self.k_l = 1.0
        if self.material.type == 'lvl':
            if self.section.Ned > 0 and self.length != 3000:
                self.k_l = min(1.1, (3000 / self.length) ** (self.material.s / 2))

        self.gammaM = get_gammaM(self.material.type)

    @property
    def R(self):
        return self.section.R

    @R.setter
    def R(self, val):
        self.section.R = val

    """
    Design values of material parameters are calculated from corresponding characteristic values
    """
    @property
    def fmd(self):
        return self.section.k_h * k_to_d(self.material.fmk, self.kmod, self.gammaM)

    @property
    def ft0d(self):
        if self.material.type == 'solid_timber' or self.material.type == 'glt':
            return self.section.k_h * k_to_d(self.material.ft0k, self.kmod, self.gammaM)
        elif self.material.type == 'lvl':
            return self.k_l * k_to_d(self.material.ft0k, self.kmod, self.gammaM)

    @property
    def ft90d(self):
        # TODO kysy samilta mikä on lvl materiaalin parametrien vastaavuus glt:hen nähden
        if self.material.type == 'lvl':
            raise Exception('lvl does not have ft90d, try ft90edged')
        return k_to_d(self.material.ft90k, self.kmod, self.gammaM)

    @property
    def fc0d(self):
        return k_to_d(self.material.fc0k, self.kmod, self.gammaM)

    @property
    def fc90d(self):
        if self.material.type == 'lvl':
            raise Exception('lvl does not have fc90d, try fc90edged or fc90flatd')
        return k_to_d(self.material.fc90k, self.kmod, self.gammaM)

    @property
    def fvd(self):
        return k_to_d(self.material.fvk, self.kmod, self.gammaM)

    @property
    def fm0flatd(self):
        if self.material.type == 'glt' or self.material.type == 'solid_timber':
            raise Exception(f'{self.material.type} does not have fm0flatd, try fmd')
        return k_to_d(self.material.fm0flatk, self.kmod, self.gammaM)

    @property
    def ft90edged(self):
        if self.material.type == 'glt' or self.material.type == 'solid_timber':
            raise Exception(f'{self.material.type} does not have ft90edged, try ft90d')
        return k_to_d(self.material.ft90edgek, self.kmod, self.gammaM)

    @property
    def fc90edged(self):
        if self.material.type == 'glt' or self.material.type == 'solid_timber':
            raise Exception(f'{self.material.type} does not have fc90edged, try fc90d')
        return k_to_d(self.material.fc90edgek, self.kmod, self.gammaM)

    @property
    def fc90flatd(self):
        if self.material.type == 'glt' or self.material.type == 'solid_timber':
            raise Exception(f'{self.material.type} does not have fc90flatd, try fc90d')
        return k_to_d(self.material.fc90flatk, self.kmod, self.gammaM)

    @property
    def fr0d(self):
        if self.material.type == 'glt' or self.material.type == 'solid_timber':
            raise Exception(f'{self.material.type} does not have fr0d')
        return k_to_d(self.material.fr0k, self.kmod, self.gammaM)

    @property
    def Sj1(self):
        return self.__Sj1

    @Sj1.setter                         # TODO vaihda jäykkyyksien arvot
    def Sj1(self, val):

        if val < 1e-4:
            val = 1e-4
        elif val > 1e20:
            val = 1e20
        if len(self.element_ids) > 0:
            idx = self.element_ids[0]
            ele = self.elements[idx]
            ele.rot_stiff[0] = val

        self.__Sj1 = val

    @property
    def Sj2(self):
        return self.__Sj2

    @Sj2.setter                         # TODO vaihda jäykkyyksien arvot
    def Sj2(self, val):

        if val < 1e-4:
            val = 1e-4
        elif val > 1e20:
            val = 1e20
        if len(self.element_ids) > 0:
            idx = self.element_ids[-1]
            ele = self.elements[idx]
            ele.rot_stiff[1] = val

        self.__Sj2 = val

    @property
    def length(self):
        # returns the length of the member defined between two points
        start_node, end_node = np.asarray(self.coordinates)
        l = np.linalg.norm(end_node - start_node)
        return l

    @property
    def Y(self):
        (x1, y1), (x2, y2) = self.coordinates
        return np.asarray([y1, y2])

    @Y.setter
    def Y(self, val):
        (x1, y1), (x2, y2) = self.coordinates
        self.coordinates = [[x1, val], [x2, val]]

    @property
    def start_coord(self):
        return self.coordinates[0]

    @property
    def end_coord(self):
        return self.coordinates[1]

    @property
    def perpendicular(self):
        """
        Reuturns vector perpendicular to member
        :return:
        """
        unit = self.unit
        if self.reverse:
            return np.array([-unit[1], unit[0]])

        return np.array([unit[1], -unit[0]])

    @property
    def A(self):
        return self.section.A

    @property
    def Iy(self):
        return self.section.I[0]

    @Iy.setter
    def Iy(self, val):
        self.section.I[0] = val

    @property
    def Iz(self):
        return self.section.I[1]

    @Iz.setter
    def Iz(self, val):
        self.section.I[1] = val

    @property
    def E0mean(self):
        return self.material.E0mean

    @E0mean.setter
    def E0mean(self, val):
        self.material.E0mean = val

    @property
    def nu(self):
        return self.material.nu

    @property
    def angle(self):
        """
        Returns member's angle in radians
        """
        start_node, end_node = self.coordinates
        x0, y0 = start_node
        x1, y1 = end_node
        if (x1 - x0) == 0:
            angle = np.radians(90)
        else:
            angle = np.arctan((y1 - y0) / (x1 - x0))
            if angle < 0:
                return np.radians(180) + angle
        return angle

    @property
    def coordinates(self):
        if self.n1 and self.n2:
            self.__coordinates = [list(self.n1.coord), list(self.n2.coord)]
            # self.calc_nodal_coordinates(self.num_elements)
        return self.__coordinates

    @coordinates.setter
    def coordinates(self, val):
        if not self.n1:
            self.__coordinates = val
            self.calc_nodal_coordinates()
        else:
            self.__coordinates = val
            x1, y1 = val[0]
            x2, y2 = val[1]
            self.n1.coord = np.array([x1, y1])
            self.n2.coord = np.array([x2, y2])
            for mem in self.n1.parents:
                mem.calc_nodal_coordinates()
            for mem in self.n2.parents:
                mem.calc_nodal_coordinates()

    @property
    def dx(self):
        vals = {}
        dx_max = 0
        for displacements in self.nodal_displacements.values():
            for load_id, disp_vals in displacements.items():
                dx, dy, rz = disp_vals
                if abs(dx) > abs(dx_max):
                    vals[load_id] = dx
                    dx_max = dx

        return vals

    @property
    def dy(self):
        vals = {}
        dy_max = 0
        for displacements in self.nodal_displacements.values():
            for load_id, disp_vals in displacements.items():
                dx, dy, rz = disp_vals
                if abs(dy) > abs(dy_max):
                    vals[load_id] = dy
                    dy_max = dy

        return vals

    @property
    def weight(self):
        """
        Function that calculates member's weight
        :return weight: float, weight of the member
        """
        weight = self.A * self.length * self.material.rhomean
        return weight

    @property
    def h(self):
        """
        Property, returns member's cross-section's height
        """
        return self.H

    @h.setter
    def h(self, val):
        """
        Sets cross-section's height to given value.
        """
        self.section = TimberSection(self.material, self.B, val)
        self.H = val

    @property
    def b(self):
        """
        Property, returns member's cross-section's breadth
        """
        return self.B

    @b.setter
    def b(self, val):
        """
        Sets cross-section's height to given value.
        """
        self.section = TimberSection(self.material, val, self.H)
        self.B = val

    @property
    def locs(self):
        locs = []
        for node in self.nodes.values():
            ncoord = np.asarray(node.coord)
            start_coord, end_coord = np.asarray(self.coordinates)
            loc = np.linalg.norm(start_coord - ncoord) / self.length
            locs.append(round(loc, PREC))
        return locs

    def sigma_t0d(self, n):
        return self.ned[n] / self.section.A

    def sigma_c0d(self, n):
        return self.ned[n] / self.section.A

    def sigma_c90d(self, l, b, ned):
        """
        @param l:   sen sauvan kosketuspinnan pituus, joka rasitetaan syysuuntaa vastaan esim. pilarin päällä oleva palkki
        @param b:   palkin leveys, joka puristaa toista palkkia sen syysuuntaan nähden kohtisuorasti
        @param ned: kosketuspinnalla vallitseva normaalivoima puristavasta sauvasta
        @return:    sigma_c90d          TODO korjaa voiman toisesta sauvasta tulevaksi
        """
        '''
        Pitää 1) tarkistaa missä nodessa ollaan
        2) otetaan sen noden vanhemmat, katsotaan omasta memberistä molemmat elementit 
        3) katsotaan elementtien periusteelkla -- > elementtien normaalivoimiin --> saadaan seuraavien nodien normaalivoimat
        4) saadaan toisen vanhemman seuraava node --> tiedossa 4 noden tiedot --> ympäröivistä nodeista lasketaan geometrian perusteella halutun noden voimien komponentit
        '''
        sigma = self.ned[0] / (l * min(b, self.B))
        return sigma

    def kc_perpendicular(self, l, a, l1) -> float:
        """
        Tukipainekerroin: RIL 205-1-2009,
        @param l:   sen sauvan kosketuspinnan pituus, joka rasitetaan syysuuntaa vastaan esim. pilarin päällä oleva palkki
        @param a:   kosketuspinnan ulkopuolinen, puristetun palkin päätyyn asti ulottuva mitta, tai seuraavaan puristuspintaan
        @param l1:  puristuspintojen lähin välimatka toisiinsa nähden
        @return:    tukipainekerroin
        """
        self.update_kc90(l1)
        lc90ef = l + min(30, a, l) + min(30, l, l1 / 2)
        return lc90ef / l * self.k_c90


    def update_kc90(self, l1):
        """
        Materiaalikohtainen, tukipainekertoimen määritykseen tarkoitettu kerroin: SFS-EN 1995-1-1 § 6.1.5
        @param l1:  kosketuspintojen reunojen välinen etäisyys
        @return:
        """
        self.k_c90 = 1.0
        if self.H * 2 <= l1:
            if self.material.type == 'solid_timber':
                self.k_c90 = 1.25
            elif self.material.type == 'glt':
                self.k_c90 = 1.5
            elif self.material.type == 'lvl':
                self.k_c90 = 1.3


    def modified_fc90d(self, l1):
        """
        SFS-EN 1995-1-1 § 6.1.5
        @param l1:
        @return:
        """
        self.update_kc90(l1)
        return self.k_c90 * self.fc90d


    def sigma_md(self, n):
        return [self.myed[n] / self.section.Wel[0], self.mzed[n] / self.section.Wel[1]]


    def tau_d(self, n):
        """
        Poikkileikkauksessa vaikuttava työntövoima muutetaan leikkausjännitykseski Jourawskin kaavaa hyväksikäyttäen
        @return: palauttaa suorakaidepoikkileikkauksen leikkausjännityksen arvon, ottaa huomioon k_cr kertoimen
        """
        k_cr = 1.0
        if self.material.type == 'solid_timber' or self.material.type == 'glt':
            if not self.varnished:
                k_cr = 0.67

        return [(3/2 * self.vyed[n]) / (self.H * self.B * k_cr), (3/2 * self.vzed[n]) / (self.H * self.B * k_cr)]


    def tau_tord(self, n) -> float:
        """
        Evaluation of torsional constant Iv (or J) and torsional resistance Wv for any arbitrarily selected cross section
        require rather sophisticated calculations. In structural wood design practice, cross sections are selected using
        manufacturer's catalogs and only sometimes random section dimensions are used. In this method only rectangular
        cross sections are permitted, therefore it's possible to estimate Iv or Wv values using simple mathematical
        expressions. Equations developed here by far are not unique, one can develop better ones, but for the time being
        they are giving sufficiently close enough results to compare with commercial programs.

        Torsional constant Iv can be estimated as stated below (change the base of logarithm to get better results):
        alpha = 0.08 * log(self.H / self.B, 2.5) + 0.14
        Iv = alpha * self.H * self.B ** 3
        but... to calculate torsional stress, torsional resistance Wv is used, which can be obtained from an analogous
        equation pair (here manipulating the formula one can also get better results for some particular cross section):
        beta = 0.05 * log(self.H / self.B, 2.6) + 0.2
        Wv = beta * self.H * self.B ** 2

        Alpha and beta are based on the theoretical tables given in: T. Salmi 2000, Lujuusopin perusteet, p. 258
        Functions were tested with logarithmic base 2..3 and middle value was selected, which underestimates close to
        square-shaped section properties and overestimates high and thin section properties, optimality is at 400x70
        """
        section_height_to_width_ratio = self.H / self.B
        beta = 0.05 * log(section_height_to_width_ratio, 2.6) + 0.2
        Wv = beta * self.H * self.B ** 2
        return self.ted[n] / Wv

    def I_tor(self) -> float:
        """
        See help(tau_tord) for full description
        @return: torsional constant for rectangular cross sections
        """
        alpha = 0.08 * log(self.H / self.B, 2.5) + 0.14
        return alpha * self.H * self.B ** 3

    def k_shape(self) -> float:
        """
        SFS EN 1995-1-1 §6.1.8(6.15)
        @return: cross section factor for rectangular cross sections (circular sections not included)
        """
        return min(1.3, 1 + 0.05 * self.H / self.B)

    def sigma_alphad(self):
        pass

    def beta_c(self):
        if self.material.type == 'solid_timber':
            return 0.2
        return 0.1

    def radius_of_gyration(self):
        return [sqrt(self.section.I[0] / self.section.A), sqrt(self.section.I[1] / self.section.A)]

    def Ln(self):
        # TODO tarkista jäykkyydet puumateriaalille
        if self.Sj1 >= 1e15 and self.Sj2 >= 1e15:
            beta = 0.5
        elif (self.Sj1 >= 1e15 and self.Sj2 <= 1e3) or (self.Sj2 >= 1e15 and self.Sj1 <= 1e3):
            beta = 0.7
        else:
            beta = 1
        return [beta * self.length, beta * self.length]

    def lamda(self):
        return [self.Ln()[0] / self.radius_of_gyration()[0], self.Ln()[1] / self.radius_of_gyration()[1]]


    def lamda_rel(self):
        return [(self.lamda()[0] / pi) * sqrt(self.material.fc0k / self.material.E005),
         (self.lamda()[0] / pi) * sqrt(self.material.fc0k / self.material.E005)]


    def sigma(self):
        return [pi ** 2 * (self.material.E0mean / self.lamda()[0]),
                pi ** 2 * (self.material.E0mean / self.lamda()[1])]


    def k(self):
        return [0.5 * (1 + self.beta_c() * (self.lamda_rel()[0] - 0.3) + self.lamda_rel()[0] ** 2),
                0.5 * (1 + self.beta_c() * (self.lamda_rel()[1] - 0.3) + self.lamda_rel()[1] ** 2)]


    def k_c(self):
        # SFS-EN 1995-1-1 § 6.3.2 (6.26)
        return [(self.k()[0] + sqrt(self.k()[0] ** 2 - self.lamda_rel()[0] ** 2)) ** -1,
                (self.k()[1] + sqrt(self.k()[1] ** 2 - self.lamda_rel()[1] ** 2)) ** -1]


    def l_ef(self):
        # SFS-EN 1995-1-1 § 6.3.3 (6.1)
        # TODO SFS 1995-1-1 s. 43 Taulukko 6.1
        return self.length


    def sigma_mcrit(self):
        '''
        For member undergoing bending relative to it's stronger axis: SFS-EN 1995-1-1 § 6.3.3 (6.31)
        @return: Single value of critical stress during lateral buckling check
        '''
        return pi * sqrt(self.material.E005 * self.section.I[1] * self.material.G005 * self.I_tor()) / self.l_ef() / self.section.Wel[0]


    def lamda_relm(self):
        '''
        SFS-EN 1995-1-1 § 6.3.3 (6.30)
        @return: Relative slenderness for bending problems      TODO taarvitaanko sauvan molempien akseleiden suhteen?
        '''
        return np.sqrt(self.material.fmk / self.sigma_mcrit())


    def k_crit(self):
        # SFS-EN 1995-1-1 § 6.3.3 (6.34)
        if self.lamda_relm() <= 0.75:
            return 1
        elif 0.75 <= self.lamda_relm() <= 1.4:
            return 1.56 - 0.75 * self.lamda_relm()
        else:
            return 1 / self.lamda_relm() ** 2


    def check_normal_force(self, n):
        # Normal force utilization ratio along the grain:           SFS-EN 1995-1-1 § 6.1.2 and 6.1.4
        if self.ned[n] > 0:
            UN = round(abs(self.sigma_t0d(n)) / self.ft0d, 5)
        else:
            UN = round(abs(self.sigma_t0d(n)) / self.fc0d, 5)
        r = UN
        return r
#        return print('Normal force resistance capacity utilized until', UN * 100, '%')


    def check_perpendicular_tension(self):
        # Member tension perpendicular to the grain:                SFS-EN 1995-1-1 § 6.1.3
        # TODO syyn suuntaan vastaset voimat
        pass


    def check_perpendicular_compression(self):
        # Member compression perpendicular to the grain:            SFS-EN 1995-1-1 § 6.1.5
        r = round(self.sigma_c90d() / (self.k_c90 * self.fc90d), 5)
        return r


    def check_shear_force(self, n):
        # Shear force utilization ratio:                            SFS-EN 1995-1-1 § 6.1.7
        UVy = round(abs(self.tau_d(n)[0]) / self.fvd, 5)
        UVz = round(abs(self.tau_d(n)[1]) / self.fvd, 5)
        r = max(UVy, UVz)
        return r
#        return print('Shear force resistance capacity utilized until', UV * 100, '%')

    def check_bending_moment(self, n):
        # Bending moment utilization ratio: TODO en:ssä f_md:lle arvot 2 eri suuntaan    SFS-EN 1995-1-1 § 6.1.6
        UM1 = round(self.sigma_md(n)[0] / self.fmd + k_m * self.sigma_md(n)[1] / self.fmd, 5)
        UM2 = round(self.sigma_md(n)[1] / self.fmd + k_m * self.sigma_md(n)[0] / self.fmd, 5)
        r = max(UM1, UM2)
        return r

    def check_torsion(self, n):
        # Torsion utilization ratio:                                SFS-EN 1995-1-1 § 6.1.8
        UTx = round(self.tau_tord(n) / (self.k_shape() * self.fvd), 5)
        r = UTx
        return r

    def check_inclined_compression(self):
        # TODO vinossa vaikuttavat puristusjännitykset              SFS-EN 1995-1-1 § 6.2.2
        pass
    # def alpha(self):
    #     return (sauvan.loppupisteen.korkeus - sauvan.alkupisteen.korkeus) / sauvan.pituus

    # def km_alpha(self):
    #     if self.ned >= 0:
    #         return np.sqrt(1 + (self.fmd * tan(alpha) / 0.75 / self.fvd) ** 2 + (self.fmd * (tan(alpha) ** 2) / self.ft90d) ** 2) ** -1
    #     else:
    #         return np.sqrt(1 + (self.fmd * tan(alpha) / 1.5 / self.fvd) ** 2 + (self.fmd * (tan(alpha) ** 2) / self.ft90d) ** 2) ** -1

    def check_bending_tension(self, n):
        #                                                           SFS-EN 1995-1-1 § 6.2.3
        UM1 = round(self.sigma_t0d(n) / self.ft0d + self.sigma_md(n)[0] / self.fmd + k_m * self.sigma_md(n)[1] / self.fmd, 5)
        UM2 = round(self.sigma_t0d(n) / self.ft0d + k_m * self.sigma_md(n)[0] / self.fmd + self.sigma_md(n)[1] / self.fmd, 5)
        r = max(UM1, UM2)
        return r

    def check_bending_compression(self, n):
        #                                                           SFS-EN 1995-1-1 § 6.2.4
        UM1 = round((self.sigma_c0d(n) / self.fc0d) ** 2 + self.sigma_md(n)[0] / self.fmd + k_m * self.sigma_md(n)[1] / self.fmd, 5)
        UM2 = round((self.sigma_c0d(n) / self.fc0d) ** 2 + k_m * self.sigma_md(n)[0] / self.fmd + self.sigma_md(n)[1] / self.fmd, 5)
        r = max(UM1, UM2)
        return r

    def check_buckling(self):
        # Utilization ratio against member buckling:                SFS-EN 1995-1-1 § 6.3.2
        n = 0
        UB = [self.sigma_c0d(n) / (self.k_c()[0] * self.fc0d) + self.sigma_md(n)[0] / self.fmd + k_m * self.sigma_md(n)[1] / self.fmd,
            self.sigma_c0d(n) / (self.k_c()[1] * self.fc0d) + k_m * self.sigma_md(n)[0] / self.fmd + self.sigma_md(n)[1] / self.fmd]
        return UB
#        return print('Member buckling capacity first in y-, then in z-directions utilized until', r * 100, '%')

    def check_LT_buckling(self):
        # Utilization ratio against member lateral buckling:        SFS-EN 1995-1-1 § 6.3.3 (3) and (6)
        n = 0
        if self.myed[0] != 0 and self.ned[0] == 0:
            ULT = self.sigma_md(n)[0] / (self.k_crit() * self.fmd)
        else:
            ULT = (self.sigma_md(n)[0] / self.k_crit() * self.fmd) ** 2 + self.sigma_c0d(n) / (self.k_c()[1] * self.fc0d)
        r = ULT
        return r


    def add_section(self, ned=0.0, myed=0.0, mzed=0.0, vyed=0.0, vzed=0.0,
                    ted=0.0, loc=0.0):
        """ Adds new section with internal forces and their location """

        self.ned.append(ned)
        self.myed.append(myed)
        self.mzed.append(mzed)
        self.vyed.append(vyed)
        self.vzed.append(vzed)
        self.ted.append(ted)
        self.loc.append(loc)

    def clear_sections(self):
        self.ned.clear()
        self.myed.clear()
        self.mzed.clear()
        self.vyed.clear()
        self.vzed.clear()
        self.ted.clear()
        self.loc.clear()

    def check_section(self, n=0, verb=False):
        """ Verify resistance of section 'n'
            returns a list of utilization ratios
        """

        r = self.section_resistance(n=n, verb=verb)
        return r


    def section_resistance(self, n=0, axis='y', return_list=True, verb=False):
        """ Calculates resistance of cross-section
            Checks the following:
                Axial force
                Shear force
                Bending moment
                Torsion
                Interaction of tension and bending moment
                Interaction of compression and bending moment
            output: r .. maximum value of different utilization ratios
        """
        if axis == 'y':
            idx = 0
        else:
            idx = 1

        UN = self.check_normal_force(n)
        #UNcp = self.check_perpendicular_compression()
        UV = self.check_shear_force(n)
        UM = self.check_bending_moment(n)
        UT = self.check_torsion(n)
        UBT = self.check_bending_tension(n)
        UBC = self.check_bending_compression(n)
        #UB = self.check_buckling()
        #ULT = self.check_LT_buckling()


        #return print('Normaalivoiman käyttöaste =', UN * 100, '%')

        if return_list:
            return [UN, UV, UM, UT, UBT, UBC]
        # else:
        #     return max([UN, UV, UM, UT, UBT, UBC])

    #
    #
    #     if self.C < 3:
    #         MNRd = self.moment_axial_force_interact(UN, self.MRd[idx])
    #         if MNRd > 0.0:
    #             UMN = abs(self.Med) / MNRd
    #         else:
    #             UMN = UN + UM
    #             # UMN = INFEASIBLE
    #     else:
    #         UMN = UN + UM
    #
    #     if return_list:
    #         r = [UN, UV, UM, UMN]
    #     else:
    #         r = max([UN, UV, UM, UMN])
    #
    #     if verb:
    #         print("Cross-section design: " + self.__repr__() + " S" + str(self.fy))
    #         print("NEd = {0:4.2f} kN; NRd = {1:4.2f} kN => UN = {2:4.2f}".format(self.Ned * 1e-3, self.NRd * 1e-3, UN))
    #         print("VEd = {0:4.2f} kN; VRd = {1:4.2f} kN => UV = {2:4.2f}".format(self.Ved * 1e-3, self.VRd * 1e-3, UV))
    #         print(
    #             "MEd = {0:4.2f} kNm; MRd = {1:4.2f} kNm => UM = {2:4.2f}".format(self.Med * 1e-6, self.MRd[idx] * 1e-6,
    #                                                                              UM))
    #
    #     return r

    def check_cross_section(self):
        """ Checks if cross-section is strong enough.
            Gives boolean value for self.is_strong_enough
            Saves list of stress ratios to self.r
        """

        self.r = np.zeros_like(self.r) # [0, 1, 2, .. 8]
        # Cross-sectional stress ratios in member's nodes' locations
        self.r[:6] = self.check_sections()
        # Buckling about y - and z - axis
        buckling_r = self.check_buckling()
        self.r[6] = buckling_r[0]
        self.r[7] = buckling_r[1]
        # Lateral-Torsional buckling
        self.r[8] = self.check_LT_buckling()

        if max(self.r) > 1.0:
            self.is_strong_enough = False
        else:
            self.is_strong_enough = True

    def check_sections(self, class1or2=True, verb=False):
        """ Verify resistance of all sections """
        r = np.zeros_like(self.check_section())
        for n in range(self.nsect()):
            r = np.vstack((r, self.check_section(n)))
            # r.append(self.check_section(n))
        return np.max(r, axis=0)


    def nsect(self):
        """ Number of sections """
        return len(self.ned)

    def line_intersection(self, coordinates):
        """
        Calculates coordinate where two members intersect
        :param coordinates: array of two arrays of two float values, [[x1,y1],[x2,y2]]
        :return [px, py]: array of two float values, coordinates for intersection
        source: https://en.wikipedia.org/wiki/Line%E2%80%93line_intersection
        """

        start_node, end_node = self.coordinates
        x1, y1 = start_node
        x2, y2 = end_node
        x3, y3 = coordinates[0]
        x4, y4 = coordinates[1]

        if round(((x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)), 10) == 0:
            return None
        else:
            px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (
                        x3 * y4 - y3 * x4)) / (
                         (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4))
            py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (
                        x3 * y4 - y3 * x4)) / (
                         (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4))

            return [round(px, 5), round(py, 5)]

    def to_global(self, loc):
        """
        Returns local coordinate in global coordinates
        :param loc: local coordinate
        :return: global coordinate
        """
        Lx = self.length * loc
        return self.coordinates[0] + Lx * self.unit

    @property
    def unit(self):
        """
        Returns unit vector
        :return:
        """
        start, end = np.asarray(self.coordinates)
        unit = np.array(end - start) / self.length
        return unit

    def calc_nodal_coordinates(self, num_elements=0) -> None:
        """
            Calculates node locations along member
            Coordinates used are global coordinates
            Adds locations to a list where they can be accessed later
            :param num_elements: int, number of elements to be created
        """
        self.nodal_coordinates.clear()
        """ add optional coordinates that are derived from point loads and supports
            etc. that are located between end points of the member.
        """
        self.nodal_coordinates.extend(self.added_coordinates)

        """ By default, 5 elements are created, but this can be changed by
            'num_elements'
        """
        if num_elements > 0:
            self.num_elements = num_elements

        for loc in np.linspace(0, 1, self.num_elements + 1):

            loc = round(loc, PREC)  # round local coordinate to PREC decimals

            """ WHY IS THIS if LOOP HERE? """
            if loc not in self.node_locs:
                self.node_locs.append(loc)

            coord = list(self.to_global(loc))
            self.nodal_coordinates.append(coord)

        """ Sort coordinates according to their distance from the
            first end node
        """
        c0, c1 = self.coordinates
        self.nodal_coordinates.sort(
            key=lambda c: np.linalg.norm(np.asarray(c0) - np.asarray(c)))

        if self.is_generated:
            for j, node in enumerate(self.nodes.values()):
                node.coord = np.array(self.nodal_coordinates[j])

    def add_node_coord(self, coord: list) -> None:
        """
        Adds coordinate to member's coordinates and
        calculates new coordinate's local location
        If coordinate is not between member's coordinates, reject it
        :param coord: array of two float values, node's coordinates
        """
        # if coord not in self.nodal_coordinates and self.point_intersection(coord):
        coord = list(coord)
        if coord not in self.added_coordinates and self.point_intersection(
                coord):
            self.added_coordinates.append(coord)
            self.nodal_coordinates.append(coord)
            c0, c1 = self.coordinates
            self.nodal_coordinates.sort(
                key=lambda c: np.linalg.norm(np.asarray(c0) - np.asarray(c)))
            start_node, end_node = self.coordinates
            x, y = coord
            x1, y1 = start_node
            dx = x - x1
            dy = y - y1
            dz = sqrt((dx ** 2 + dy ** 2))
            z = dz / self.length

            if x < x1:
                z *= -1
            z = round(z, PREC)
            if z not in self.node_locs:
                self.node_locs.append(z)
                self.node_locs.sort()

    def point_intersection(self, coordinate):
        """
        Calculates if member and point intersect
        :param coordinate: array of two float values
        :return bool: true if point and member intersect
        """

        start_node, end_node = self.coordinates
        x1, y1 = start_node
        x2, y2 = end_node
        x, y = coordinate
        # Coordinate is between member's coordinates
        if x1 <= x <= x2 and y1 <= y <= y2:
            if x2 - x1 == 0:
                y1, y2 = sorted([y1, y2])
                return x == x1 and y1 <= y <= y2
            else:
                k = (y2 - y1) / (x2 - x1)
                b = y1 - k * x1
                return isclose(y, k * x + b,
                                    rel_tol=1e-3)  # y == k * x + b

        return False

    def add_material(self, fem_model):
        """ Adds member's material information to calculation model
            Young's modulus MPa
            TODO tarkista G parametri (sen suuntaus ja arvo)
            Density kg/m^3
        """
        fem_model.add_material(self.E0mean, self.material.Gmean, self.material.rhomean)

    # TODO lisää femiin sectio
    # def add_section(self, fem_model):
    #     """ Units: mm A and I_y are in mm**2 and mm**4, respectively"""
    #     s = fem.BeamSection(self.cross_section.A, self.cross_section.I[0])
    #     fem_model.add_section(s)

    def calc_nodal_forces(self):
        """ Gets calculated nodal forces on member's elements and
            adds them to dict where node is the key and froces are value
            self.nodal_forces[node_id] = [Fx, Fy, Mz]
        """

        def absmax(vals):
            min_val = min(vals)
            max_val = max(vals)
            abs_max = max(abs(min_val), abs(max_val))
            if abs_max == abs(min_val):
                return min_val
            else:
                return max_val

        max_med = 0
        max_ved = 0
        max_ned = 0

        i = 0
        node_ids = list(self.nodes.keys())
        for element in self.elements.values():
            node_id = node_ids[i]
            axial_force = absmax(element.axial_force)
            if abs(axial_force) > abs(max_ned):
                max_ned = axial_force

            shear_force = absmax(element.shear_force)
            if abs(shear_force) > abs(max_ved):
                max_ved = shear_force

            bending_moment = absmax(element.bending_moment)
            if abs(bending_moment) > abs(max_med):
                max_med = bending_moment

            self.nodal_forces[node_id] = [axial_force,
                                          shear_force,
                                          bending_moment]
            i += 1

            if i == len(self.elements):

                node_id = node_ids[i]
                axial_force = absmax(element.axial_force)
                if abs(axial_force) > abs(max_ned):
                    max_ned = axial_force

                shear_force = absmax(element.shear_force)
                if abs(shear_force) > abs(max_ved):
                    max_ved = shear_force

                bending_moment = absmax(element.bending_moment)
                if abs(bending_moment) > abs(max_med):
                    max_med = bending_moment

                self.nodal_forces[node_id] = [axial_force,
                                              shear_force,
                                              bending_moment]

        self.Med = max_med
        self.Ved = max_ved
        self.Ned = max_ned

    def calc_nodal_displacements(self, fem_model):
        """ Calculates nodal displacements and saves them to a dict
            :param fem_model: FrameFEM -object
        """
        for node in self.nodes:
            self.nodal_displacements[node] = fem_model.nodes[node].u

    def generate_eccentricity_elements(self, fem_model):
        """ Generates eccentricity elements to connections
        """
        # Material id
        mat_id = len(fem_model.materials)
        # Add material
        # Material(E, nu, rho)
        fem_model.add_material(210e3, 0.3, 7850e-9)
        # Add section
        # BeamSection(A, Iy)
        # HE 1000 A
        # A = 34680
        # Iy = 5538000000
        sect_id = len(fem_model.sections)
        # TODO ehkä vaihda HEA jokskin puu sectioksi?
        sect = HEA(1000)
        fem_model.add_section(sect)
        for coordinates in self.ecc_coordinates:
            for i, coord in enumerate(coordinates):
                coordinates[i] = [round(c, PREC) for c in coord]
            idx = fem_model.nels()
            # n1 is the node connected to the column
            # n2 is hinged connection to chord
            n1 = fem_model.nodes[fem_model.nodal_coords.index(coordinates[0])]
            n2 = fem_model.nodes[fem_model.nodal_coords.index(coordinates[1])]
            self.ecc_elements[idx] = EBBeam(n1, n2,
                                            fem_model.sections[sect_id],
                                            fem_model.materials[mat_id])
            # rot_stiff=[np.inf, 0])
            fem_model.add_element(self.ecc_elements[idx])

    def generate(self, fem_model):
        """ Generates the member
        """
        # If the frame hasn't been created, create members and calculate nodal
        # coordinates, otherwise initialize frame.

        if not self.is_generated:
            self.add_nodes(fem_model)
            self.add_material(fem_model)
            self.add_section(fem_model)
            self.generate_elements(fem_model)
            self.is_generated = True

    def add_nodes(self, fem_model):
        """ Creates nodes to previously calculated locations
        """
        idx = None
        for coordinate in self.nodal_coordinates:
            x, y = coordinate
            if coordinate in fem_model.nodal_coords:
                idx = fem_model.nodal_coords.index(coordinate)
                self.nodes[idx] = fem_model.nodes[idx]
                self.nodes[idx].parents.append(self)
            else:
                idx = fem_model.nnodes()
                fem_model.add_node(x, y)
                self.nodes[idx] = fem_model.nodes[idx]
                self.nodes[idx].parents.append(self)
            if not self.n1:
                self.n1 = fem_model.nodes[idx]
                # Add last node
        if not self.n2 and idx:
            self.n2 = fem_model.nodes[idx]

    def generate_elements(self, fem_model):
        """ Generates elements between nodes
            For beam member's first and last element, creates semi-rigid end
            elements. Elements are added to a list
            :param fem_model: FrameFEM -object
        """
        index = fem_model.nels()
        node_ids = list(self.nodes.keys())
        # EBBeam -elements
        if self.mtype == "column":

            for i in range(len(self.nodes) - 1):
                n1 = node_ids[i]
                n2 = node_ids[i + 1]

                self.elements[index] = \
                    EBBeam(fem_model.nodes[n1], fem_model.nodes[n2],
                           self.section,
                           self.material)

                fem_model.add_element(self.elements[index])
                self.element_ids.append(index)
                index += 1
        elif self.mtype == 'bar':
            """ Simple bar element that carries only axial forces """
            n1 = node_ids[0]
            n2 = node_ids[1]
            self.elements[index] = \
                    Rod(fem_model.nodes[n1], fem_model.nodes[n2],
                                    self.section,
                                    self.material)
            fem_model.add_element(self.elements[index])
            self.element_ids.append(index)
        elif self.mtype != "column":
            if len(self.nodes) == 2:
                n1 = node_ids[0]
                n2 = node_ids[1]

                self.elements[index] = \
                    EBSemiRigidBeam(fem_model.nodes[n1], fem_model.nodes[n2],
                                    self.section,
                                    self.material,
                                    rot_stiff=[self.Sj1, self.Sj2])
                fem_model.add_element(self.elements[index])
                self.element_ids.append(index)
            else:
                for i in range(len(self.nodes) - 1):
                    n1 = node_ids[i]
                    n2 = node_ids[i + 1]

                    # EBSemiRigid -element, first element
                    if i == 0:
                        self.elements[index] = \
                            EBSemiRigidBeam(fem_model.nodes[n1],
                                            fem_model.nodes[n2],
                                            self.section,
                                            self.material,
                                            rot_stiff=[self.Sj1, np.inf])
                    # EBSemiRigid -element, last element
                    elif i == (len(self.nodes) - 2):
                        self.elements[index] = \
                            EBSemiRigidBeam(fem_model.nodes[n1],
                                            fem_model.nodes[n2],
                                            self.section,
                                            self.material,
                                            rot_stiff=[np.inf, self.Sj2])
                    # EBBeam -elements
                    else:
                        self.elements[index] = \
                            EBBeam(fem_model.nodes[n1], fem_model.nodes[n2],
                                   self.section,
                                   self.material)

                    fem_model.add_element(self.elements[index])
                    self.element_ids.append(index)
                    index += 1

    def round_coordinates(self, prec=PREC):
        """ Rounds the nodal coordinates with the precision of 'prec'
            (number of decimals)
        """

        for i, coord in enumerate(self.nodal_coordinates):
            self.nodal_coordinates[i] = [round(c, prec) for c in coord]

    def assign_forces(self):
        """
        Assigns forces to SteelMember -object.
        Creates new sections if none are created,
        otherwise updates old values
        """

        self.clear_sections()
        for i, element in enumerate(self.elements.values()):
            M1, M2 = element.bending_moment
            N1, N2 = element.axial_force
            V1, V2 = element.shear_force
            loc = self.locs[i]
            self.add_section(ned=N1, vzed=V1,
                             myed=M1, loc=loc)
        loc = self.locs[i + 1]
        self.add_section(ned=N2, vzed=V2,
                         myed=M2, loc=loc)

    def lineload_elements(self, coords):

        # Returns the elements that are under line load
        #:param coords: 2D-array of float, line load's start and end coordinates
        #:return element_ids: array of int, elements id's

        start, end = coords
        start = [round(c, PREC) for c in start]
        end = [round(c, PREC) for c in end]
        start_idx = self.nodal_coordinates.index(start)
        end_idx = self.nodal_coordinates.index(end)
        element_ids = self.element_ids[start_idx:end_idx]
        return element_ids

    def plot(self, print_text=True, c='k', axes=None):

        if axes is None:
            fig, ax = plt.subplots(1)
        else:
            ax = axes

        X = self.coordinates
        if c:
            if self.is_strong_enough:
                color = 'green'
            else:
                color = 'red'
        else:
            color = 'k'
        # Plot members
        ax.plot([X[0][0], X[1][0]], [X[0][1], X[1][1]], color)
        # Plot text

        if self.mtype == 'beam':
            horzalign = 'center'
            vertalign = 'bottom'

        elif self.mtype == 'column':
            horzalign = 'right'
            vertalign = 'center'

        else:
            horzalign = 'center'
            vertalign = 'center'

        x, y = self.to_global(0.3) - self.perpendicular * 50
        rot = np.degrees(self.angle)

        if print_text:
            ax.text(x, y, str(self.mem_id) + ": " + str(self.section),
                     rotation=rot, horizontalalignment=horzalign,
                     verticalalignment=vertalign)
        else:
            ax.text(x, y, str(self.mem_id),
                     rotation=rot, horizontalalignment=horzalign,
                     verticalalignment=vertalign)

    def sfd(self, scale):
        """
        Plots shear force diagram
        :param scale: float, scaling factor
        """

        X = []
        Y = []
        self.calc_nodal_forces()
        X.append(self.nodal_coordinates[0][0])
        Y.append(self.nodal_coordinates[0][1])
        for i in range(len(self.nodes)):
            node = self.nodes[i]
            if self.mtype == "beam":
                x0 = self.nodal_coordinates[i][0]
                y0 = self.nodal_coordinates[i][1]
                y1 = self.nodal_forces[node][1] / (1000 / scale)
                x = x0
                y = y0 - y1
                X.append(x)
                Y.append(y)
            elif self.mtype == "column":
                x0 = self.nodal_coordinates[i][0]
                y0 = self.nodal_coordinates[i][1]
                x1 = self.nodal_forces[node][1] / (1000 / scale)
                x = x0 + x1
                y = y0
                X.append(x)
                Y.append(y)
        X.append(self.nodal_coordinates[i][0])
        Y.append(self.nodal_coordinates[i][1])
        plt.plot(X, Y, color='gray')

    def bmd_test(self, scale=1):

        # Scales Nmm to kNm
        unit_scaler = 1e-6

        # Member's position vector
        v = self.unit
        # Vector perpendicular to v
        u = -self.perpendicular
        X = []
        Y = []
        start_coord, end_coord = self.coordinates
        x01, y01 = start_coord
        x02, y02 = end_coord
        X.append(x01)
        Y.append(y01)
        self.calc_nodal_forces()

        moment_values = [x[2] for x in self.nodal_forces.values()]

        for elem in self.elements.values():
            x0, y0 = elem.nodes[0].coord
            bending_moment = elem.bending_moment[0]
            val = bending_moment * unit_scaler * scale
            x, y = np.array([x0, y0]) - val * u
            X.append(x)
            Y.append(y)
            horzalign = 'center'
            vertalign = 'center'
            if bending_moment == max(moment_values) or bending_moment == min(
                    moment_values):
                plt.text(x, y, f'{bending_moment * unit_scaler:.2f} kNm',
                         horizontalalignment=horzalign)
        x0, y0 = elem.nodes[1].coord
        bending_moment = elem.bending_moment[1]
        val = bending_moment * unit_scaler * scale
        x, y = np.array([x0, y0]) - val * u
        X.append(x)
        Y.append(y)
        X.append(x02)
        Y.append(y02)
        plt.text(x, y, f'{bending_moment * unit_scaler:.2f} kNm',
                 horizontalalignment=horzalign)
        plt.plot(X, Y, color='brown')

    def __repr__(self):
        return f"{type(self).__name__}({self.coordinates})"