from structures.timber.timber_member import TimberMember
from structures.timber.timber_frame2d import TimberFrame2D
from materials.timber_data import T
from sections.timber.timber_section import TimberSection, GypsumPlasterboardF, WoodenFireProtection
import frame2d.frame2d as f2d
import numpy as np

fr = TimberFrame2D()

coord1 = [[0, 0], [0, 3000]]
coord3 = [[0, 3000], [10000, 3000]]
coord2 = [[10000, 5000], [10000, 0]]
coord4 = [[0, 3000], [0, 6000]]
coord5 = [[0, 6000], [10000, 6000]]
coord6 = [[10000, 6000], [10000, 3000]]
fr.add(TimberMember(T.GL32c, 200, 200, coord1, 'instantaneous', 1))
fr.members[0].section = TimberSection(fr.members[0].material, fr.members[0].B, fr.members[0].H,
                                      fire_protection_generic=GypsumPlasterboardF(1))
fr.add(TimberMember(T.GL32c, 400, 200, coord3, 'instantaneous', 1, num_elements=8, Sj1=0, Sj2=0))
fr.add(TimberMember(T.GL32c, 200, 200, coord2, 'instantaneous', 1))
fr.add(TimberMember(T.GL32c, 200, 200, coord4, 'instantaneous', 1))
fr.add(TimberMember(T.GL32c, 200, 200, coord5, 'instantaneous', 1, Sj1=0, Sj2=0))
fr.add(TimberMember(T.GL32c, 200, 200, coord6, 'instantaneous', 1))

R = 60
fr.members[3].R = R
fr.members[4].R = R
fr.members[5].R = R
# fr.add(TimberMember(T.Kerto_Q_21_24))
# fr.add(f2d.PointLoad([50.0, 2500.0], [30000, 0, 0]))
fr.add(f2d.LineLoad(fr.members[1], [-15, -15], 'y'))
fr.add(f2d.LineLoad(fr.members[4], [-15, -15], 'y'))
fr.add(f2d.LineLoad(fr.members[0], [2, 3], 'x'))
fr.add(f2d.LineLoad(fr.members[3], [3, 4], 'x'))
fr.add(f2d.FixedSupport([0, 0]))
fr.add(f2d.FixedSupport([10000, 0]))
fr.generate()
fr.calculate()
# print(fr.members[0].check_section())
fr.members[1].check_cross_section()
print(fr.members[1].r)
#fr.bmd(10)
fr.plot_deflection()
fr2 = TimberFrame2D()