# -*- coding: utf-8 -*-
"""
Created on Fri Aug 30 19:35:41 2019

@author: kmela
"""

import matplotlib.pyplot as plt

foa_step = [0,1,2,3]

foa_u = [0,0.0257417,0.0514835,0.0772253]

plt.plot(foa_u,foa_step)